import numpy as np

EARTH_RADIUS_KM = 6371

def geodetic_to_ecef(lat, lon, alt_km):
    """ 地理坐标转ECEF坐标 (修正保持原功能) """
    lat_rad = np.radians(lat)
    lon_rad = np.radians(lon)
    r = EARTH_RADIUS_KM + alt_km
    x = r * np.cos(lat_rad) * np.cos(lon_rad)
    y = r * np.cos(lat_rad) * np.sin(lon_rad)
    z = r * np.sin(lat_rad)
    return np.array([x, y, z])

def haversine_angle(lat1, lon1, lat2, lon2):
    """ 大圆角计算 (保持不变) """
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat/2)**2 + np.cos(lat1)*np.cos(lat2)*np.sin(dlon/2)**2
    c = 2 * np.arcsin(np.sqrt(a))
    return c

def does_line_intersect_cloud_plane(sat_ecef, tgt_ecef, cloud_height_km, cloud_lat_min, cloud_lat_max, cloud_lon_min, cloud_lon_max):
    """ 改进后的云层相交判断 """
    R_cloud = EARTH_RADIUS_KM + cloud_height_km  # 云层球面半径

    # ------ 步骤1: 判断线段是否穿过云层球面 ------
    r_sat = np.linalg.norm(sat_ecef)  # np.linalg.norm 计算矩阵l2范数
    r_tgt = np.linalg.norm(tgt_ecef)
    
    # 两点都在云层内部或外部 -> 无交点
    if (r_sat <= R_cloud) and (r_tgt <= R_cloud):
        return False
    if (r_sat >= R_cloud) and (r_tgt >= R_cloud):
        return False

    # ------ 步骤2: 计算线段与云层球面的交点 ------
    direction = tgt_ecef - sat_ecef
    a = np.dot(direction, direction)
    b = 2 * np.dot(sat_ecef, direction) # np.dot 向量点积
    c_val = np.dot(sat_ecef, sat_ecef) - R_cloud**2
    delta = b**2 - 4 * a * c_val

    if delta < 0:  # 无实根，不相交
        return False
    t1 = (-b + np.sqrt(delta)) / (2 * a)
    t2 = (-b - np.sqrt(delta)) / (2 * a)
    valid_ts = [t for t in [t1, t2] if 0 <= t <= 1]  # 参数t在[0,1]内

    if not valid_ts:
        return False
    t = min(valid_ts)  # 取最近的交点
    cross_point = sat_ecef + t * direction

    # ------ 步骤3: 转换交点坐标并判断范围 ------
    x, y, z = cross_point
    r = np.linalg.norm(cross_point)
    lat_rad = np.arcsin(z / r)          # [-2/pi,2pi]
    lon_rad = np.arctan2(y, x)          # [-pi, pi]
    lat_deg = np.degrees(lat_rad)       # np.degrees 弧度转化度数
    lon_deg = np.degrees(lon_rad)  
    lon_deg = (lon_deg + 180) % 360 - 180 

    # 检查是否在目标区域
    return (
        cloud_lat_min <= lat_deg <= cloud_lat_max and
        cloud_lon_min <= lon_deg <= cloud_lon_max
    )
def simulate_observable_positions(
    target_topleft_lat, 
    target_topleft_lon,
    target_bottomright_lat, 
    target_bottomright_lon,
    cloud_height_km=10,
    sat_alt_km=617,
    max_off_nadir_deg=45,
    lat_margin_deg=5,
    lon_margin_deg=5,
    step_deg=0.2
):
    lat_min = min(target_topleft_lat, target_bottomright_lat)
    lat_max = max(target_topleft_lat, target_bottomright_lat)
    lon_min = min(target_topleft_lon, target_bottomright_lon)
    lon_max = max(target_topleft_lon, target_bottomright_lon)

    # 四个点的坐标
    corners_ground = [
        (lat_min, lon_min),
        (lat_min, lon_max),
        (lat_max, lon_min),
        (lat_max, lon_max),
    ]

    results = []
    lat_range = np.arange(lat_min - lat_margin_deg, lat_max + lat_margin_deg + step_deg, step_deg)
    lon_range = np.arange(lon_min - lon_margin_deg, lon_max + lon_margin_deg + step_deg, step_deg)

    # 添加edge-star坐标 字典-记录卫星序号
    edge_sat = [
        {"name": "Sat1", "lat": -3.62573740207768, "lon": 39.20273367550462},
        {"name": "Sat2", "lat": -5.23584738908546, "lon": 42.01601859586557},
        {"name": "Sat3", "lat": -8.46986824639548, "lon": 42.03518783385252},
        {"name": "Sat4", "lat": -10.09647068654874, "lon": 39.20273367550462},
        {"name": "Sat5", "lat": -8.46986824639548, "lon": 36.37027951715675},
        {"name": "Sat6", "lat": -5.23584738908546, "lon": 36.38944875514369},
    ]

    # 循环每个卫星lon,lat坐标
    # for sat_lat in lat_range:
    for sat in edge_sat:
        sat_name = sat["name"]
        sat_lat = sat["lat"]
        sat_lon = sat["lon"]
        sat_ecef = geodetic_to_ecef(sat_lat, sat_lon, sat_alt_km)
        visible = True
        max_off_nadir = 0

        # 循环矩形框 (lat,lon) 坐标
        for tgt_lat, tgt_lon in corners_ground:
            tgt_ecef = geodetic_to_ecef(tgt_lat, tgt_lon, 0)

            # 判断是否穿过云层平面区域
            if does_line_intersect_cloud_plane(sat_ecef, tgt_ecef,cloud_height_km,lat_min, lat_max,lon_min, lon_max):
                visible = False
                break

            # 离轴角计算
            slant_range = np.linalg.norm(sat_ecef - tgt_ecef)
            ground_range = haversine_angle(sat_lat, sat_lon, tgt_lat, tgt_lon) * EARTH_RADIUS_KM
            ratio = np.clip(ground_range / slant_range, -1.0, 1.0)
            off_nadir = np.degrees(np.arcsin(ratio))
            max_off_nadir = max(max_off_nadir, off_nadir)

        if visible and max_off_nadir <= max_off_nadir_deg:
            results.append({
                "sat_name": sat_name,
                "sat_lat": sat_lat,
                "sat_lon": sat_lon,
                "off_nadir_deg": max_off_nadir,
                "sat_alt_km": sat_alt_km
            })

    return results

if __name__ == "__main__":
    # 设置目标区域
    target_topleft_lat = -8.8611040443132145
    target_topleft_lon = 39.202733675504625
    target_bottomright_lat = -8.8622060256385495
    target_bottomright_lon = 39.20383565682996

    # 调用主模拟函数
    results = simulate_observable_positions(
        target_topleft_lat=target_topleft_lat,
        target_topleft_lon=target_topleft_lon,
        target_bottomright_lat=target_bottomright_lat,
        target_bottomright_lon=target_bottomright_lon,
        cloud_height_km=10,
        sat_alt_km=617,
        max_off_nadir_deg=30,
        lat_margin_deg=10,
        lon_margin_deg=10, # 搜索范围
        step_deg=1
    )

    # 输出结果
    print(f"\n✅ 共找到 {len(results)} 个可观测位置：\n")
    for res in results[:100]:  # 只打印前10个
        print(res)

    # 找出 off_nadir_deg 最小的那颗卫星
    print(f"\n🚀 找到最佳卫星：\n")
    best_sat = min(results, key=lambda x: x["off_nadir_deg"])
    # 打印结果
    print(f"'sat_name': {best_sat['sat_name']},'sat_lat': {best_sat['sat_lat']},'sat_lon': {best_sat['sat_lon']},'off_nadir_deg': {best_sat['off_nadir_deg']:.14f},'sat_alt_km': {best_sat['sat_alt_km']}\n")


