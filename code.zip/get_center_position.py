import rasterio
import os

""" 读取图片坐标 """
def get_dd_from_tif(tiff_file):
 
    with rasterio.open(tiff_file) as src:
        # 获取图像的地理参考信息
        transform = src.transform
        crs = src.crs
        # 提取图像的四个顶点像素坐标
        width = src.width
        height = src.height
        # 获取左上、右上、左下和右下四个顶点的像素坐标
        corners_pixel = [(0, 0), (width, 0), (0, height), (width, height)]    
        # 将像素坐标转换为经纬度
        corners_geo = [transform * corner for corner in corners_pixel]
        # 获取文件名（不包含路径）
        file_name = tiff_file.split("\\")[-1]
        # 提取 Top-left 和 Bottom-right 经纬度
        top_left = corners_geo[0]
        bottom_right = corners_geo[3]
        
        # print(top_left[0],top_left[1],bottom_right[0],bottom_right[1])
        return (top_left[0],top_left[1],bottom_right[0],bottom_right[1])
    
""" 计算中心卫星坐标 """
def get_center_position(top_left_lon,top_left_lat,botton_right_lon,botton_right_lat):
    
    center_lon = (top_left_lon + botton_right_lon)/2
    center_lat = (top_left_lat + botton_right_lat)/2
    
    return(center_lon,center_lat)

""" 十进制转换为度分秒 """
def decimal_to_dms(decimal_degrees):
    degrees = int(decimal_degrees)
    minutes_decimal = abs(decimal_degrees - degrees) * 60
    minutes = int(minutes_decimal)
    seconds = (minutes_decimal - minutes) * 60
    return degrees, minutes, seconds

if __name__ == "__main__":
    
    folder_path = r"D:\Project\schedule\pass\tif_image"
    tiff_files = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(".tif")]

    print(tiff_files)

    for tiff_file in tiff_files:
       
    # 读取图片顶点坐标
        position = get_dd_from_tif(tiff_file) # 返回四个参数
        # 得到中心卫星位置
        center_position = get_center_position(*position) # 返回两个参数

        print(f"纬度：{center_position[1]},经度：{center_position[0]}")

        # 转换为度分秒
        lat_d, lat_m, lat_s = decimal_to_dms(center_position[1])
        lon_d, lon_m, lon_s = decimal_to_dms(center_position[0])
        print(f"纬度: {lat_d}° {lat_m}' {lat_s:.6f}\"")
        print(f"经度: {lon_d}° {lon_m}' {lon_s:.6f}\"")
