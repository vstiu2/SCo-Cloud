import math

def spherical_circle_points(lat0_deg, lon0_deg, alt_km=617, radius_km=500, n_points=6):
    # 地球参数
    R_e = 6378.137  # 地球赤道半径（单位：km）
    R = R_e + alt_km  # 球面半径（轨道高度）
    
    # 中心点弧度
    lat0 = math.radians(lat0_deg)
    lon0 = math.radians(lon0_deg)
    
    # 球面弧长对应的角度
    delta_sigma = radius_km / R  # 单位：弧度

    # 存储结果
    points = []

    for i in range(n_points):
        # 圆周方向角（单位：弧度）
        theta = 2 * math.pi * i / n_points

        # 球面偏移公式
        sin_phi = math.sin(lat0) * math.cos(delta_sigma) + \
                  math.cos(lat0) * math.sin(delta_sigma) * math.cos(theta)
        phi = math.asin(sin_phi)

        delta_lambda = math.atan2(
            math.sin(theta) * math.sin(delta_sigma) * math.cos(lat0),
            math.cos(delta_sigma) - math.sin(lat0) * sin_phi
        )
        lambda_ = lon0 + delta_lambda

        # 转换回度
        lat_i = math.degrees(phi)
        lon_i = math.degrees(lambda_)
        # 保证经度范围在 [-180, 180]
        lon_i = (lon_i + 180) % 360 - 180

        points.append({
            "name": f"Sat{i + 1}",
            "lat": lat_i,
            "lon": lon_i
        })

    return points

# # 以某卫星点为中心，求圆上6个点
# lat0 = -6.8611040443132145    # 纬度
# lon0 = 39.202733675504625   # 经度
# alt = 617       # 高度（km）
# radius = 395      # 圆的半径（km），390是极限

# result = spherical_circle_points(lat0, lon0, alt_km=alt, radius_km=radius, n_points=6)

# # 输出结果
# print("圆周上6个等间隔点的经纬度(单位：度):")
# print(result)
# for i, (name,lat, lon) in enumerate(result):
#     # print(f"点{i+1}: 纬度 = {lat:.14f}°, 经度 = {lon:.14f}°")
#     print(f"({lat:.14f},{lon:.14f}),")

"建立球面：以地心为中心,半径R=Re+h的球面,也就是卫星轨道所在的高度面。"
"以给定的卫星lon,lat,alt为原点,以3km为半径,在球面上做一个圆."
"将此圆以相等的间隔采到6个点,因此这六个点的高度都是R=Re+h,得到6个点的lon lat"