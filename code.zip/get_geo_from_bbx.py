from PIL import Image
import pandas as pd
import os
import rasterio

""" 读取整个图片经纬度坐标 """
def get_dd_from_tif(tiff_file):
    # 遍历每个文件并提取经纬度信息
    # for tiff_file in tiff_files:
    with rasterio.open(tiff_file) as src:
        # 获取图像的地理参考信息
        transform = src.transform
        crs = src.crs
        # 提取图像的四个顶点像素坐标
        width = src.width
        height = src.height
        # 获取左上、右上、左下和右下四个顶点的像素坐标
        corners_pixel = [(0, 0), (width, 0), (0, height), (width, height)]    
        # 将像素坐标转换为经纬度
        corners_geo = [transform * corner for corner in corners_pixel]
        # 获取文件名（不包含路径）
        file_name = tiff_file.split("\\")[-1]
        # 提取 Top-left 和 Bottom-right 经纬度
        top_left = corners_geo[0]
        bottom_right = corners_geo[3]
        
        return (top_left[0],top_left[1],bottom_right[0],bottom_right[1])
    
""" 将 BBX 像素坐标 转换 为地理坐标（经纬度）"""
def bbx_to_geo_coords(x1,y1,x2,y2,image_path,position,filename):

    # 打开图像，获取宽高
    with Image.open(image_path) as img:
        width, height = img.size
    
    lon_min, lat_max, lon_max, lat_min = position

    # 计算单位像素对应的经纬度偏移
    lon_per_pixel = (lon_max - lon_min) / width
    lat_per_pixel = (lat_max - lat_min) / height

    geo_bbx_list = []
    # for x1, y1, x2, y2 in bbx_list:
    # 左上角
    lon1 = lon_min + x1 * lon_per_pixel
    lat1 = lat_max - y1 * lat_per_pixel

    # 右下角
    lon2 = lon_min + x2 * lon_per_pixel
    lat2 = lat_max - y2 * lat_per_pixel

    geo_bbx_list.append((filename,lon1, lat1, lon2, lat2))

    return geo_bbx_list

if __name__ == "__main__":
    
    folder_path = r'D:\Project\schedule\pass\tif_image'
    tiff_files = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(".tif")]
    
    csv_path = r'D:\Project\schedule\pass\cloud_bboxes_0409.csv'
    df = pd.read_csv(csv_path)

    for tiff_file in tiff_files:
        position = get_dd_from_tif(tiff_file)  # 返回 (lon_min, lat_max, lon_max, lat_min)
        filename = os.path.basename(tiff_file).replace(".tif", ".jpg")  # .tif → .jpg，匹配 CSV 中的 filename
        matching_rows = df[df['filename'] == filename]
        for _, row in matching_rows.iterrows():
            x1, y1, x2, y2 = int(row['x1']), int(row['y1']), int(row['x2']), int(row['y2'])
            geo_coords = bbx_to_geo_coords(x1,y1,x2,y2,tiff_file, position,filename)

            for i, coords in enumerate(geo_coords):
                print(f"BBX 名称：{coords[0]}, 地理坐标：左上经纬度=({coords[1]}, {coords[2]}), 右下经纬度=({coords[3]}, {coords[3]})")
