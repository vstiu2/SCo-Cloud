import os
import pandas as pd
from get_center_position import get_center_position
from get_center_position import get_dd_from_tif
from get_geo_from_bbx import bbx_to_geo_coords
from add_change_2 import simulate_observable_positions
from get_edge_position import spherical_circle_points
if __name__ == "__main__":
   
    alt = 617
    radius = 395      # 圆的半径（km），390是极限
    # folder_path = r"D:\Project\schedule\pass\tif_image"
    folder_path = r"D:\Project\schedule\test\1164"
    tiff_files = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(".tif")]
    csv_path = r'D:\Project\schedule\pass\cloud_bboxes_0409.csv'
    df = pd.read_csv(csv_path)
    
    for tiff_file in tiff_files:
       
        # 读取图片顶点坐标
        position = get_dd_from_tif(tiff_file) # 返回四个参数
        
        # 得到中心卫星位置
        center_position = get_center_position(*position) # 返回两个参数

        # 得到边缘卫星位置
        edge_position = spherical_circle_points(center_position[1], center_position[0], alt_km=alt, radius_km=350, n_points=6)

        print(edge_position)
        # print(f"图片名称：{os.path.basename(tiff_file)}\n")
        print(f"enter-sat纬度:{center_position[1]}, center-sat经度:{center_position[0]}")

        filename = os.path.basename(tiff_file).replace(".tif", ".jpg")  # .tif → .jpg，匹配 CSV 中的 filename
        matching_rows = df[df['filename'] == filename]
        for _, row in matching_rows.iterrows():
            x1, y1, x2, y2 = int(row['x1']), int(row['y1']), int(row['x2']), int(row['y2'])
            geo_coords = bbx_to_geo_coords(x1,y1,x2,y2,tiff_file, position,filename)
            print("-------- 打印 bbx 经纬度-----------")

            for i, coords in enumerate(geo_coords):
                print(f"\n BBX 名称：{coords[0]}, 地理坐标：左上经纬度=({coords[2]}, {coords[1]}), 右下经纬度=({coords[4]}, {coords[3]})\n")
            
            # 调度
            results = simulate_observable_positions(
                target_topleft_lat= geo_coords[0][2],
                target_topleft_lon=geo_coords[0][1],
                target_bottomright_lat= geo_coords[0][4],
                target_bottomright_lon=geo_coords[0][3],
                edge_sat = edge_position,
                cloud_height_km=10,
                sat_alt_km=617,
                max_off_nadir_deg=30,
                lat_margin_deg=10,
                lon_margin_deg=10, # 搜索范围
                step_deg=0.5
            )
             # 输出结果
            print(f"\n✅ 图片{os.path.basename(tiff_file)}共找到 {len(results)} 个可观测位置：\n")
            for res in results[:100]:  # 只打印前10个
                print(res)

            # # 找出 off_nadir_deg 最小的那颗卫星
            # print(f"\n🚀 找到最佳卫星：\n")
            # best_sat = min(results, key=lambda x: x["off_nadir_deg"])
            # # 打印结果
            # print(f"'sat_name': {best_sat['sat_name']},'sat_lat': {best_sat['sat_lat']},'sat_lon': {best_sat['sat_lon']},'off_nadir_deg': {best_sat['off_nadir_deg']:.14f},'sat_alt_km': {best_sat['sat_alt_km']}\n")
            
            if results:
                best_sat = min(results, key=lambda x: x["off_nadir_deg"])
                print(f"\n🚀 找到最佳卫星：\n")
                print(f"'sat_name': {best_sat['sat_name']},'sat_lat': {best_sat['sat_lat']},'sat_lon': {best_sat['sat_lon']},'off_nadir_deg': {best_sat['off_nadir_deg']:.14f},'sat_alt_km': {best_sat['sat_alt_km']}\n")
            else:
                print("No results found. Can't compute best satellite.")
                best_sat = None
