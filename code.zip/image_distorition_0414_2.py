import cv2
import numpy as np
from math import radians, degrees, sin, cos, atan2
# from get_geo_from_bbx import bbx_to_geo_coords
import rasterio

# 计算方向角
def compute_azimuth(sat_lat, sat_lon, tgt_lat, tgt_lon):
    d_lon = radians(sat_lon - tgt_lon)
    lat1 = radians(tgt_lat)
    lat2 = radians(sat_lat)

    x = sin(d_lon) * cos(lat2)
    y = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(d_lon)

    azimuth = degrees(atan2(x, y))
    return (azimuth + 360) % 360

def simulate_distortion_on_region(image_path, angle_deg, azimuth_deg,
                                  pixel_top, pixel_left, pixel_bottom, pixel_right):
    img = cv2.imread(image_path)
    h, w = img.shape[:2]

    # 确保坐标为整数
    y_start = int(max(0, min(pixel_top, pixel_bottom)))
    y_end = int(min(h, max(pixel_top, pixel_bottom)))
    x_start = int(max(0, min(pixel_left, pixel_right)))
    x_end = int(min(w, max(pixel_left, pixel_right)))

    roi = img[y_start:y_end, x_start:x_end].copy()
    roi_h, roi_w = roi.shape[:2]

    # 模拟畸变
    shift = int(np.tan(radians(angle_deg)) * roi_h // 2)
    dx = shift * np.cos(radians(azimuth_deg))
    dy = shift * np.sin(radians(azimuth_deg))

    src = np.float32([[0, 0], [roi_w, 0], [roi_w, roi_h], [0, roi_h]])
    dst = np.float32([
        [0 + dx, 0 + dy],
        [roi_w + dx, 0 - dy],
        [roi_w - dx, roi_h - dy],
        [0 - dx, roi_h + dy],
    ])

    M = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(roi, M, (roi_w, roi_h))

    return warped

if __name__ == "__main__":
    tiff_file = 'D:/Project/schedule/test/google_1164.tif'
    
    # 使用rasterio获取地理坐标转换参数
    with rasterio.open(tiff_file) as src:
        transform = src.transform
        
        # 目标位置
        target_topleft_lat = -6.8611040443132145
        target_topleft_lon = 39.202733675504625
        target_bottomright_lat = -6.8622060256385495
        target_bottomright_lon = 39.20383565682996
        
        # 目标区域的地理坐标
        target_coords = [
            (target_topleft_lon, target_topleft_lat),  # 左上
            (target_bottomright_lon, target_bottomright_lat)  # 右下
        ]
        
        # 将地理坐标转换为像素坐标
        pixel_coords = [~transform * coord for coord in target_coords]
        x_coords = [int(coord[0]) for coord in pixel_coords]
        y_coords = [int(coord[1]) for coord in pixel_coords]
        
        pixel_top = y_coords[0]
        pixel_left = x_coords[0]
        pixel_bottom = y_coords[1]
        pixel_right = x_coords[1]

    # 卫星位置
    sat_lat, sat_lon = -5.398664896696387, 36.80908731924208
    
    # 计算中心点方向角
    tgt_lat_center = (target_topleft_lat + target_bottomright_lat) / 2
    tgt_lon_center = (target_topleft_lon + target_bottomright_lon) / 2
    azimuth_deg = compute_azimuth(sat_lat, sat_lon, tgt_lat_center, tgt_lon_center)
    
    angle_deg = 27.0

    result = simulate_distortion_on_region(
        tiff_file, angle_deg, azimuth_deg,
        pixel_top, pixel_left, pixel_bottom, pixel_right
    )
    cv2.imwrite("D:/Project/schedule/test/region_distorted_1.jpg", result)