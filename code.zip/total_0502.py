import os
import csv
import pandas as pd
import rasterio
import cv2
from get_center_position import get_center_position
from get_center_position import get_dd_from_tif
from get_geo_from_bbx import bbx_to_geo_coords
from add_change_2 import simulate_observable_positions
from get_edge_position import spherical_circle_points
from image_distorition_0414_2 import simulate_distortion_on_region
from image_distorition_0414_2 import compute_azimuth

if __name__ == "__main__":
   
    alt = 617
    radius = 395      # 圆的半径（km），390是极限
    # folder_path = r"D:\Project\schedule\pass\tif_image"
    folder_path = r'D:/dataset/xview/images_cloud'
    # folder_path = r"D:\Project\schedule\test\1164"
    tiff_files = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(".tif")]
    # csv_path = r'D:\Project\schedule\pass\cloud_bboxes_0409.csv'
    csv_path = r'D:\Project\schedule\pass\cloud_bboxes_0501.csv'

    df = pd.read_csv(csv_path)
    
    output_csv = r"D:\Project\evalute\non_satellite\non_r398_s2.csv"
    write_header = not os.path.exists(output_csv)  # 若文件不存在，则写入表头
    
    for tiff_file in tiff_files:
       
        # 读取图片顶点坐标
        position = get_dd_from_tif(tiff_file) # 返回四个参数
        
        # 得到中心卫星位置
        center_position = get_center_position(*position) # 返回两个参数

        # 得到边缘卫星位置
        edge_position = spherical_circle_points(center_position[1], center_position[0], alt_km=alt, radius_km=398, n_points=2)
        # print(edge_position)
        # print(f"图片名称：{os.path.basename(tiff_file)}\n")
        # print(f"enter-sat纬度:{center_position[1]}, center-sat经度:{center_position[0]}")
        
        # 保存图片名
        tif_filename = os.path.basename(tiff_file)
        filename = os.path.basename(tiff_file).replace(".tif", ".jpg")  # .tif → .jpg，匹配 CSV 中的 filename
        
        matching_rows = df[df['filename'] == filename]
        k = 0
        # print(k)
         
        for _, row in matching_rows.iterrows():
            x1, y1, x2, y2 = int(row['x1']), int(row['y1']), int(row['x2']), int(row['y2'])
            geo_coords = bbx_to_geo_coords(x1,y1,x2,y2,tiff_file, position,filename)
            # print("-------- 打印 bbx 经纬度-----------")

            # for i, coords in enumerate(geo_coords):
            #     print(f"\n BBX 名称：{coords[0]}, 地理坐标：左上经纬度=({coords[2]}, {coords[1]}), 右下经纬度=({coords[4]}, {coords[3]})\n")
            
            target_topleft_lat = geo_coords[0][2]
            target_topleft_lon = geo_coords[0][1]
            target_bottomright_lat = geo_coords[0][4]
            target_bottomright_lon = geo_coords[0][3]

            # 调度
            results = simulate_observable_positions(
                target_topleft_lat= geo_coords[0][2],
                target_topleft_lon=geo_coords[0][1],
                target_bottomright_lat= geo_coords[0][4],
                target_bottomright_lon=geo_coords[0][3],
                edge_sat = edge_position,
                cloud_height_km=10,
                sat_alt_km=617,
                max_off_nadir_deg=30,
                lat_margin_deg=10,
                lon_margin_deg=10, # 搜索范围
                step_deg=0.5
            )
             # 输出结果
            # print(f"\n✅ 图片{os.path.basename(tiff_file)}共找到 {len(results)} 个可观测位置：\n")
            # for res in results[:100]:  # 只打印前10个
            #     print(res)

            # # 找出 off_nadir_deg 最小的那颗卫星
            # print(f"\n🚀 找到最佳卫星：\n")
            # best_sat = min(results, key=lambda x: x["off_nadir_deg"])
            # # 打印结果
            # print(f"'sat_name': {best_sat['sat_name']},'sat_lat': {best_sat['sat_lat']},'sat_lon': {best_sat['sat_lon']},'off_nadir_deg': {best_sat['off_nadir_deg']:.14f},'sat_alt_km': {best_sat['sat_alt_km']}\n")
            
            # 输出最佳卫星
            if results:
                best_sat = min(results, key=lambda x: x["off_nadir_deg"])
                # print(f"\n🚀 找到最佳卫星：\n")
                # print(f"'sat_name': {best_sat['sat_name']},'sat_lat': {best_sat['sat_lat']},'sat_lon': {best_sat['sat_lon']},'off_nadir_deg': {best_sat['off_nadir_deg']:.14f},'sat_alt_km': {best_sat['sat_alt_km']}\n")
            else:
                print("No results found. Can't compute best satellite.")
                with open(output_csv, mode='a', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    # if write_header:
                    #     writer.writerow(['filename', 'x1', 'y1', 'x2', 'y2'])
                    writer.writerow([filename, x1, y1, x2, y2])
                best_sat = None

            # # 输出最佳卫星拍摄的图片
            # # 使用rasterio获取地理坐标转换参数
            # # google_folder_path = r'D:/Project/schedule/pass/google_imgae'
            # google_folder_path = r'D:/dataset/xview/googleload_images_cloud'
            # # google_folder_path = r'D:\dataset\xview\googleload_images_cloud_40MB'
            # google_tiff_file = os.path.join(google_folder_path, tif_filename)
            # print(google_tiff_file)
            # with rasterio.open(google_tiff_file) as src:
            #     transform = src.transform      
            #     # 目标区域的地理坐标
            #     target_coords = [
            #         (target_topleft_lon, target_topleft_lat),  # 左上
            #         (target_bottomright_lon, target_bottomright_lat)  # 右下
            #     ]
                
            #     # 将地理坐标转换为像素坐标
            #     pixel_coords = [~transform * coord for coord in target_coords]
            #     x_coords = [int(coord[0]) for coord in pixel_coords]
            #     y_coords = [int(coord[1]) for coord in pixel_coords]
                
            #     pixel_top = y_coords[0]
            #     pixel_left = x_coords[0]
            #     pixel_bottom = y_coords[1]
            #     pixel_right = x_coords[1]
                
            #     azimuth_deg = compute_azimuth(best_sat['sat_lat'], best_sat['sat_lon'], center_position[1], center_position[0])
                
            #     edge_sat_retake = simulate_distortion_on_region(
            #         google_tiff_file, best_sat['off_nadir_deg'], azimuth_deg,
            #         pixel_top, pixel_left, pixel_bottom, pixel_right
            #     )

            #     # 存放
            #     k = k + 1
            #     print(k)
            #     # 拆分文件名和扩展名
            #     file_base, file_ext = os.path.splitext(filename)
            #     file_ext = '.tif'
            #     new_filename = f"{file_base}_{k}{file_ext}"
            #     output_folder_path = r'D:\Project\schedule\pass\edge_output_tif_all'
            #     os.makedirs(output_folder_path, exist_ok=True)
            #     retake_path = os.path.join(output_folder_path,new_filename)
            #     cv2.imwrite(retake_path, edge_sat_retake)