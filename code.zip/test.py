import os
folder_path = r'D:\Project\schedule\pass\tif_image'
tiff_files = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(".tif")]

for tiff_file in tiff_files:
    print({tiff_file})